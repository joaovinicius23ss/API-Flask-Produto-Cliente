
-- Remove o schema se existir
DROP SCHEMA IF EXISTS `gestao_rh`;

-- Cria o schema novamente
CREATE SCHEMA IF NOT EXISTS `gestao_rh` DEFAULT CHARACTER SET utf8;
USE `gestao_rh`;


DROP TABLE IF EXISTS `Cliente`;
DROP TABLE IF EXISTS `Pedido`;

-- Criação da tabela Cargo
CREATE TABLE IF NOT EXISTS `Pedido` (
  `idPedido` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nomePedido` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`idPedido`),
  UNIQUE INDEX `idPedido_UNIQUE` (`idPedido` ASC),
  UNIQUE INDEX `nomePedido_UNIQUE` (`nomePedido` ASC)
) ENGINE = InnoDB;

-- Criação da tabela Funcionario
CREATE TABLE IF NOT EXISTS `Cliente` (
  `idCliente` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nomeCliente` VARCHAR(128) NULL,
  `email` VARCHAR(64) NULL,
  `senha` VARCHAR(64) NULL,
  `beneficio` TINYINT(1) NULL,
  `Pedido_idPedido` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`idCliente`),
  UNIQUE INDEX `idCliente_UNIQUE` (`idCliente` ASC),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC),
  INDEX `fk_Cliente_Pedido_idx` (`Pedido_idPedido` ASC),
  CONSTRAINT `fk_Cliente_Pedido`
    FOREIGN KEY (`Pedido_idPedido`)
    REFERENCES `Pedido` (`idPedido`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB;

-- Inserção de cargos
INSERT INTO `Pedido` (`idPedido`, `nomePedido`) VALUES (1, 'Pizza de Chocolate');
INSERT INTO `Pedido` (`idPedido`, `nomePedido`) VALUES (2, 'Pizza de Peperonni');
INSERT INTO `Pedido` (`idPedido`, `nomePedido`) VALUES (3, 'Pizza de Calabreza');
INSERT INTO `Pedido` (`idPedido`, `nomePedido`) VALUES (4, 'Pizza de Mussarela');

-- Inserção de funcionários
INSERT INTO `Cliente` (`nomeCliente`, `email`, `senha`, `beneficio`, `Pedido_idPedido`) 
VALUES 
('adm', 'adm@adm.com', '123', 1, 1),
('adm1', 'adm1@adm.com', '$2b$12$6ixafy0UKZx.A8ujEEDfnO2QH7IonQ/5/5UCqzQ51YvISdSO4VVle', 1, 1),
('Hélio', 'helioesperidiao@gmail.com', '$2b$12$6ixafy0UKZx.A8ujEEDfnO2QH7IonQ/5/5UCqzQ51YvISdSO4VVle', 1, 1);

