from flask import request, jsonify
import traceback
from api.service.cliente_service import ClienteService

class ClienteControl:
    def __init__(self, cliente_service: ClienteService):
        print("⬆️  ClienteControl.constructor()")
        self.__cliente_service = cliente_service

    def login(self):
        print ("🔵 ClienteControl.login()")

        json_cliente = request.json.get("cliente")
        resultado = self.__cliente_service.loginCliente(json_cliente)
        return jsonify({
            "success": True,
            "message": "Login efetuado com sucesso!",
            "data": resultado
        }), 201
    

    def store(self):
        print("🔵 ClienteControl.store()")
        
        json_cliente= request.json.get("cliente")
        newIdCliente = self.__Cliente_service.createCliente(json_cliente)
        return jsonify({
        "success": True,
        "message": "Cadastro realizado com sucesso",
        "data": {
            "cliente": {
                "idCliente": newIdCliente,
                "nomeCliente": json_cliente.get("nomeCliente"),
                "email": json_cliente.get("email"),
                "senha": json_cliente.get("senha"),  
                "beneficio": json_cliente.get("beneficio"),
                "pedido": {
                    "idPedido": json_cliente.get("pedido", {}).get("idPedido"),
                    "nomePedido": json_cliente.get("pedido", {}).get("nomePedido")
                }
            }
        }
    }), 201
        

    def index(self):        
        lista_clientes = self.__cliente_service.findAll()
        return jsonify({
            "success": True,
            "message": "Executado com sucesso",
            "data": {"cliente": lista_clientes}
        }), 200
        

    def show(self, idCliente):
        cliente = self.__cliente_service.findById(idCliente)
        return jsonify({
            "success": True,
            "message": "Executado com sucesso",
            "data": cliente
        }), 200
        

    def update(self, idCliente):
        cliente_atualizado = self.__cliente_service.updateCliente(idCliente, request.json)

        if cliente_atualizado: 
            return jsonify({
                "success": True,
                "message": "Atualizado com sucesso",
                "data": {
                    "cliente": {
                        "idCliente": int(idCliente),
                        "nomeCliente": request.json.get("cliente", {}).get("nomeCliente")
                    }
                }
            }), 200
        else:
            return jsonify({
                "success": False,
                "error": {
                    "message": f"Não foi possível atualizar o funcionário com ID {idCliente}",
                    "code": 404
                },
                "data": {}
            }), 404

    def destroy(self, idCliente):
        
        excluiu = self.__cliente_service.deleteCliente(idCliente)
        if not excluiu:
            return jsonify({
                "success": False,
                "message": "Cliente não encontrado",
                "error": {"message": f"Não existe cliente com id {idCliente}"}
            }), 404

        return jsonify({
            "success": True,
            "message": "Excluído com sucesso"
        }), 204
        
