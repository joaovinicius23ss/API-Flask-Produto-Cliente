from flask import request, jsonify
from api.service.pedido_service import PedidoService
class PedidoControl:
    def __init__(self, pedido_service:PedidoService):
        print("⬆️  PedidoControl.constructor()")
        self.__pedido_service = pedido_service
    def store(self):
        print("🔵 PedidoControle.store()")
       
        pedido_body_request = request.json.get("pedido")
        novo_id = self.__pedido_service.createPedido(pedido_body_request)

        obj_resposta = {
            "success": True,
            "message": "Cadastro realizado com sucesso",
            "data": {
                "pedido": [
                    {
                        "idPedido": novo_id,
                        "nomePedido": pedido_body_request.get("nomePedido")
                    }
                ]
            }
        }
        if novo_id:
            return jsonify(obj_resposta), 200
    def index(self):
        print("🔵 PedidoControle.index()")
       
        array_pedido = self.__pedido_service.findAll()
        
        return jsonify({
            "success": True,
            "message": "Busca realizada com sucesso",
            "data": {"pedido": array_pedido}
        }), 200
        

    def show(self):
        idPedido = request.view_args.get("idPedido")

        pedido = self.__pedido_service.findById(idPedido)
        obj_resposta = {
            "success": True,
            "message": "Executado com sucesso",
            "data": {"pedidos": pedido}
        }
        return jsonify(obj_resposta), 200
      

    def update(self):
        print("🔵 PedidoControle.update()")
       
        idPedido = request.view_args.get("idPedido")
        json_pedido = request.json.get("pedido")
        print(json_pedido)

        resposta = self.__pedido_service.updatePedido(idPedido, json_pedido)
        return jsonify({
            "success": True,
            "message": "Pedido atualizado com sucesso",
            "data": {
                "pedido": {
                    "idPedido": int(idPedido),
                    "nomePedido": json_pedido.get("nomePedido")
                }
            }
        }), 200
   

    def destroy(self):
        print("🔵 PedidoControle.destroy()")
        idPedido = request.view_args.get("idPedido")
        
        excluiu = self.__pedido_service.deletePedido(idPedido)
        if not excluiu:
            return jsonify({
                "success": False,
                "message": f"Não existe Pedido com id {idPedido}"
            }), 404

        return jsonify({
            "success": True,
            "message": "Excluído com sucesso"
        }), 204