from flask import Blueprint, request
from api.middleware.jwt_middleware import JwtMiddleware
from api.middleware.pedido_middleware import PedidoMiddleware
from api.control.pedido_control import PedidoControl

class PedidoRoteador:
    def __init__(self, jwt_middleware: JwtMiddleware, pedido_middleware: PedidoMiddleware, pedido_control: PedidoControl):
        print("⬆️  PedidoRoteador.__init__()")
        self.__jwt_middleware = jwt_middleware
        self.__Pedido_middleware = pedido_middleware
        self.__Pedido_control = pedido_control
        self.__blueprint = Blueprint('pedido', __name__)

    def create_routes(self):

        @self.__blueprint.route('/', methods=['POST'])
        @self.__jwt_middleware.validate_token  
        @self.__Pedido_middleware.validate_body
        def store():
            return self.__Pedido_control.store()

        @self.__blueprint.route('/', methods=['GET'])
        @self.__jwt_middleware.validate_token  
        def index():
            return self.__Pedido_control.index()
        @self.__blueprint.route('/<int:idPedido>', methods=['GET'])
        @self.__jwt_middleware.validate_token
        @self.__Pedido_middleware.validate_id_param
        def show(idPedido):
            return self.__Pedido_control.show(idPedido)
        
        @self.__blueprint.route('/<int:idPedido>', methods=['PUT'])
        @self.__jwt_middleware.validate_token
        @self.__Pedido_middleware.validate_id_param
        @self.__Pedido_middleware.validate_body
        def update(idPedido):
            return self.__Pedido_control.update()
        
        @self.__blueprint.route('/<int:idPedido>', methods=['DELETE'])
        @self.__jwt_middleware.validate_token
        @self.__Pedido_middleware.validate_id_param
        def destroy(idPedido):
            return self.__Pedido_control.destroy()

        return self.__blueprint
