from flask import Blueprint, request
from functools import wraps
from api.middleware.jwt_middleware import JwtMiddleware
from api.middleware.cliente_middleware import ClienteMiddleware
from api.control.cliente_control import ClienteControl

class ClienteRoteador:
    def __init__(self, jwt_middleware:JwtMiddleware, cliente_middleware : ClienteMiddleware, cliente_control:ClienteControl):
        print("⬆️  ClienteRoteador.__init__()")
        self.jwt_middleware = jwt_middleware
        self.cliente_middleware = cliente_middleware
        self.cliente_control = cliente_control
        self.blueprint = Blueprint('cliente', __name__)

    def create_routes(self):

        @self.blueprint.route('/login', methods=['POST'])
        @self._flask_decorator(self.cliente_middleware.validate_login_body)
        def login():
            print("clienteRoteador.login()")
            
            return self.cliente_control.login()

        @self.blueprint.route('/', methods=['POST'])
        @self.jwt_middleware.validate_token
        @self._flask_decorator(self.cliente_middleware.validate_create_body)
        def store():
            
            return self.cliente_control.store()

        @self.blueprint.route('/<int:idCliente>', methods=['PUT'])
        @self.jwt_middleware.validate_token
        @self._flask_decorator(self.cliente_middleware.validate_id_param)
        @self._flask_decorator(self.cliente_middleware.validate_create_body)
        def update(idCliente):
            return self.cliente_control.update(idCliente)

        @self.blueprint.route('/<int:idCliente>', methods=['DELETE'])
        @self.jwt_middleware.validate_token
        @self._flask_decorator(self.cliente_middleware.validate_id_param)
        def destroy(idCliente):
            return self.cliente_control.destroy(idCliente)
        
        @self.blueprint.route('/', methods=['GET'])
        @self.jwt_middleware.validate_token
        def index():
            return self.cliente_control.index()
        @self.blueprint.route('/<int:idCliente>', methods=['GET'])
        @self.jwt_middleware.validate_token
        @self._flask_decorator(self.cliente_middleware.validate_id_param)
        def show(idCliente):
            return self.cliente_control.show(idCliente)
        return self.blueprint

    def _flask_decorator(self, middleware_func):
        def decorator(f):
            @wraps(f)
            def wrapper(*args, **kwargs):
                middleware_func(request)
                return f(*args, **kwargs)
            return wrapper
        return decorator
