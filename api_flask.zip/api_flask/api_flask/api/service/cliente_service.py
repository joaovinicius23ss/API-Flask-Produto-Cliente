from api.dao.cliente_dao import ClienteDAO
from api.dao.pedido_dao import PedidoDAO
from api.model.cliente import Cliente
from api.model.pedido import Pedido
from api.utils.error_response import ErrorResponse
from api.http.meu_token_jwt import MeuTokenJWT

class ClienteService:
    def __init__(self, cliente_dao_dependency: ClienteDAO, pedido_dao_dependency: PedidoDAO):
        print("⬆️  ClienteService.__init__()")
        self.__clienteDAO = cliente_dao_dependency
        self.__cargoDAO = pedido_dao_dependency

    def createCliente(self, jsonCliente: dict) -> Cliente:

        print("🟣 ClienteService.createCliente()")

        objPedido = Pedido()
        objPedido.idPedido = jsonCliente["pedido"]["idPedido"]

        objCliente = Cliente()
        objCliente.nomeCliente = jsonCliente["nomeCliente"]
        objCliente.email = jsonCliente["email"]
        objCliente.senha = jsonCliente["senha"]
        objCliente.beneficio = jsonCliente["beneficio"]
        objCliente.pedido = objPedido

        pedidoExiste =  self.__pedidoDAO.findByField("idPedido", objCliente.pedido.idPedido)
        if not pedidoExiste:
            raise ErrorResponse(
                400,
                "O pedido informado não existe",
                {"message": f"O pedido {objCliente.pedido.idPedido} não foi encontrado"}
            )

        emailExiste =  self.__clienteDAO.findByField("email", objCliente.email)
        if emailExiste and len(emailExiste) > 0:
            raise ErrorResponse(
                400,
                "Cliente já existe",
                {"message": f"O email {objCliente.email} já está cadastrado"}
            )

        
        return self.__clienteDAO.create(objCliente)
   

    def loginCliente(self, jsonCliente: dict) -> dict:
        print("🟣 ClienteService.loginCliente()")
        print(jsonCliente)

        objCliente = Cliente()
        objCliente.email = jsonCliente["email"]
        objCliente.senha = jsonCliente["senha"]
      
        encontrado = self.__clienteDAO.login(objCliente)

        if not encontrado:
            raise ErrorResponse(
                401,
                "Usuário ou senha inválidos",
                {"message": "Não foi possível realizar autenticação"}
            )

        jwt = MeuTokenJWT()
        user = {
            "cliente": {
                "email": encontrado.email,
                "role": getattr(encontrado.cargo, "nomePedido", None),
                "name": encontrado.nomeCliente,
                "idCliente": encontrado.idCliente
            }
        }
        return {"user": user, "token": jwt.gerarToken(user["cliente"])}
    

    def findAll(self) -> list[dict]:
        print("🟣 ClienteService.findAll()")
        return  self._clienteDAO.findAll()

    def findById(self, idCliente: int) -> dict:
        
        objCliente = Cliente()
        objCliente.idCliente = idCliente 

        cliente =  self.__clienteDAO.findById(objCliente.idCliente)
        if not cliente:
            raise ErrorResponse(
                404,
                "Funcionário não encontrado",
                {"message": f"Não existe cliente com id {idCliente}"}
            )
        return cliente

    def updateCliente(self, idCliente: int, requestBody: dict) -> bool:
        print("🟣 ClienteService.updateCliente()")

        jsonCliente = requestBody["cliente"]

        objPedido = Pedido()
        objPedido.idPedido= jsonCliente["pedido"]["idPedido"]

        objCliente = Cliente()
        objCliente.idCliente = idCliente
        objCliente.nomeCliente = jsonCliente["nomeCliente"]
        objCliente.email = jsonCliente["email"]
        objCliente.senha = jsonCliente["senha"]
        objCliente.recebeValeTransporte = jsonCliente["recebeValeTransporte"]
        objCliente.pedido = objPedido

        return  self.__clienteDAO.update(objCliente)

    def deleteCliente(self, idCliente: int) -> bool:
        print("🟣 ClienteService.deleteCliente()")
        return  self.__clienteDAO.delete(idCliente)