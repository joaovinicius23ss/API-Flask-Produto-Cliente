from api.dao.pedido_dao import PedidoDAO
from api.model.pedido import Pedido
from api.utils.error_response import ErrorResponse
class PedidoService:
    def __init__(self, pedido_dao_dependency: PedidoDAO):
        print("⬆️  PedidoService.__init__()")
        self.__pedidoDAO = pedido_dao_dependency  
    def createPedido(self, pedidoBodyRequest: dict) -> int:
        print("🟣 PedidoService.createPedido()")

        pedido = Pedido()
        pedido.nomePedido= pedidoBodyRequest.get("nomePedido")

        resultado = self.__pedidoDAO.findByField("nomePedido", pedido.nomePedido)
        if resultado and len(resultado) > 0:
            raise ErrorResponse(
                400,
                "Pedido já existe",
                {"message": f"O pedido {pedido.nomePedido} já existe"}
            )

        return  self.__pedidoDAO.create(pedido)

    def findAll(self) -> list[dict]:
        print("🟣 PedidoService.findAll()")
        return self.__pedidoDAO.findAll()

    def findById(self, idPedido: int) -> dict | None:
        print("🟣 PedidoService.findById()")

        pedido = Pedido()
        pedido.idPedido = idPedido 

        return self.__pedidoDAO.findById(pedido.idPedido)

    def updatePedido(self, idPedido: int, jsonPedido: dict) -> bool:
        print (jsonPedido)
        print("🟣 PedidoService.updatePedido()")

        pedido = Pedido()
        pedido.idPedido = idPedido
        pedido.nomePedido = jsonPedido.get("nomePedido")

        return self.__pedidoDAO.update(pedido)

    def deletePedido(self, idPedido: int) -> bool:
        print("🟣 PedidoService.deletePedido()")
        pedido = Pedido()
        pedido.idPedido = idPedido

        return self.__pedidoDAO.delete(pedido)
