from api.model.pedido import Pedido
class Cliente:
    def __init__(self):
        self.__idCliente = None
        self._pedido = None
        self.__nomeCliente = None
        self.__email = None
        self.__senha = None
        self.__benefico = None
    @property
    def idCliente(self):
        return self.__idCliente

    @idCliente.setter
    def idCliente(self, valor):
        try:
            parsed = int(valor)
        except (ValueError, TypeError):
            raise ValueError("idCliente deve ser um número inteiro.")
        if parsed <= 0:
            raise ValueError("idCliente deve ser um número inteiro positivo.")
        self.__idCliente = parsed

    @property
    def pedido(self):
        return self.__pedido
    @pedido.setter
    def pedido(self, value):

        if not isinstance(value, Pedido):
            raise ValueError("pedido deve ser uma instância válida de CLiente.")
        self.__pedido = value

    @property
    def nomeCliente(self):
        return self.__nomeCliente

    @nomeCliente.setter
    def nomeCliente(self, value):
        if not isinstance(value, str):
            raise ValueError("nomeCliente deve ser uma string.")

        nome = value.strip()

        if len(nome) < 3:
            raise ValueError("nomeCliente deve ter pelo menos 3 caracteres.")

        self.__nomeCliente = nome
    @property
    def email(self):
        return self.__email

    @email.setter
    def email(self, value):
        if not isinstance(value, str):
            raise ValueError("email deve ser uma string.")

        email_trimmed = value.strip()

        if email_trimmed == "":
            raise ValueError("email não pode ser vazio.")

        import re
        email_regex = r"^[^\s@]+@[^\s@]+\.[^\s@]+$"
        if not re.match(email_regex, email_trimmed):
            raise ValueError("email em formato inválido.")

        self.__email = email_trimmed

    @property
    def senha(self):
        return self.__senha

    @senha.setter
    def senha(self, value):

        if not isinstance(value, str):
            raise ValueError("senha deve ser uma string.")

        senha_trimmed = value.strip()

        if senha_trimmed == "":
            raise ValueError("senha não pode ser vazia.")

        if len(senha_trimmed) < 6:
            raise ValueError("senha deve ter pelo menos 6 caracteres.")

        if not any(c.isupper() for c in senha_trimmed):
            raise ValueError("senha deve conter pelo menos uma letra maiúscula.")

        if not any(c.isdigit() for c in senha_trimmed):
            raise ValueError("senha deve conter pelo menos um número.")

        if not any(c in "!@#$%^&*(),.?\":{}|<>" for c in senha_trimmed):
            raise ValueError("senha deve conter pelo menos um caractere especial.")

        self.__senha = senha_trimmed

    @property
    def beneficio(self):
        return self.__benefico

    @beneficio.setter
    def beneficio(self, value):
        if value not in (0, 1):
            raise ValueError("beneficio deve ser 0 ou 1.")
        self.__beneficio = value
