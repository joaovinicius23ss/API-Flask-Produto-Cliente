class Pedido:
    def __init__(self):
        self.__idPedidio = None
        self.__nomePedido = None
    @property
    def idPedidio(self):
        return self.__idPedido

    @idPedidio.setter
    def idPedido(self, value):

        try:
            parsed = int(value)
        except (ValueError, TypeError):
            raise ValueError("idPedido deve ser um número inteiro.")

        if parsed <= 0:
            raise ValueError("idPedido deve ser maior que zero.")

        self.__idPedido = parsed

    @property
    def nomePedido(self):
        return self.__nomePedido

    @nomePedido.setter
    def nomePedido(self, value):
        if not isinstance(value, str):
            raise ValueError("nomePedido deve ser uma string.")

        nome = value.strip()
        if len(nome) < 3:
            raise ValueError("nomePedido deve ter pelo menos 3 caracteres.")

        self.__nomePedido = nome
