import bcrypt
from api.model.cliente import Cliente
from api.model.pedido import Pedido

class ClienteDAO:
    def __init__(self, database_dependency):
        print("⬆️  ClienteDAO.__init__()")
        self.__database = database_dependency

    def create(self, objCliente: Cliente) -> int:
        print("🟢 ClienteDAO.create()")
        hashed = bcrypt.hashpw(objCliente.senha.encode("utf-8"), bcrypt.gensalt())
        objCliente.senha = hashed.decode("utf-8")

        SQL = """
            INSERT INTO cliente 
            (nomeCliente, email, senha, recebeValeTransporte, Pedido_idPedido) 
            VALUES (%s, %s, %s, %s, %s);
        """
        params = (
            objCliente.nomeCliente,
            objCliente.email,
            objCliente.senha,
            objCliente.beneficio,
            objCliente.pedido.idPedido,
        )

        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL, params)
                conn.commit()
                insert_id = cursor.lastrowid

        if not insert_id:
            raise Exception("Falha ao inserir cliente")
        return insert_id

    def delete(self, idCliente: int) -> bool:
        print("🟢 ClienteDAO.delete()")
        SQL = "DELETE FROM cliente WHERE idCliente = %s;"

        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL, (idCliente,))
                conn.commit()
                affected = cursor.rowcount

        return affected > 0

    def update(self, objCliente: Cliente) -> bool:
        print("🟢 ClienteDAO.update()")
        if objCliente.senha:
            senhaHash = bcrypt.hashpw(objCliente.senha.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
            SQL = """
                UPDATE cliente 
                SET nomeCliente=%s, email=%s, senha=%s, beneficio=%s, Cliente_idCliente=%s 
                WHERE idCliente=%s;
            """
            params = (
                objCliente.nomeCliente,
                objCliente.email,
                senhaHash,
                objCliente.beneficio,
                objCliente.pedido.idPedido,
                objCliente.idCliente,
            )
        else:
            SQL = """
                UPDATE cliente 
                SET nomeCliente=%s, email=%s, beneficio=%s, Pedido_idPedido=%s 
                WHERE idCliente=%s;
            """
            params = (
                objCliente.nomeCliente,
                objCliente.email,
                objCliente.beneficio,
                objCliente.pedido.idPedido,
                objCliente.idCliente,
            )

        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL, params)
                conn.commit()
                affected = cursor.rowcount

        return affected > 0

    def findAll(self) -> list[dict]:
        print("🟢 ClienteDAO.findAll()")
        SQL = """
            SELECT idCliente,nomeCliente,email,beneficio,idPedido,nomePedido 
            FROM cliente
            JOIN pedido on cliente.Pedido_idPedido = idPedido;
        """
        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL)
                rows = cursor.fetchall()

        cliente = [
            {
                "idCliente": row["idCliente"],
                "nomeCliente": row["nomeCliente"],
                "email": row["email"],
                "beneficio": row["beneficio"],
                "pedido": {
                    "idPedido": row["idPedido"],
                    "nomePedido": row["nomePedido"]
                }
            }
            for row in rows
        ]
        return cliente

    def findById(self, idCliente: int) -> dict | None:
        clientesRaw = self.findByField("idCliente", idCliente)
        print("✅ ClienteDAO.findById()")
        return clientesRaw[0] if clientesRaw else None

    def findByField(self, campo: str, valor) -> list[dict]:
        print(f"🟢 ClienteDAO.findByField() - Campo: {campo}, Valor: {valor}")
        allowedFields = ["idCliente", "nomeCliente", "email", "senha", "beneficio", "Pedido_idPedido"]
        if campo not in allowedFields:
            raise ValueError("Campo inválido para busca")

        SQL = f"SELECT * FROM cliente WHERE {campo} = %s;"
        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL, (valor,))
                resultados = cursor.fetchall()

        return resultados

    def login(self, objCliente: Cliente) ->Cliente | None:
        print("🟢 ClienteDAO.login()")
        SQL = """
            SELECT 
                idCliente, 
                nomeCliente,
                email, 
                senha, 
                beneficio, 
                idPedido, 
                nomePedido
            FROM cliente
            JOIN pedido ON pedido.idPedido = cliente.Pedido_idPedido
            WHERE email=%s;
        """
        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL, (objCliente.email,))
                rows = cursor.fetchall()
        if len(rows) != 1:
            print("Cliente não encontrado")
            return None

        clienteDB = rows[0]

        if not bcrypt.checkpw(
            objCliente.senha.encode("utf-8"),
            clienteDB["senha"].encode("utf-8")
        ):
            print("Senha inválida")
            return None

        objCargo = Pedido()
        objCargo.idCargo = int(clienteDB["idCargo"])
        objCargo.nomeCargo = clienteDB["nomeCargo"]

        cliente = Cliente()
        cliente.idCliente = clienteDB["idCliente"]
        cliente.cargo = objCargo
        cliente.nomeCliente =clienteDB["nomeCliente"]
        cliente.email = clienteDB["email"]
        cliente.recebeValeTransporte = clienteDB["recebeValeTransporte"]

        print("✅ ClienteDAO.login() -> sucesso")
        return cliente
