from api.model.pedido import Pedido
class PedidoDAO:
    def __init__(self, database_dependency):
        print("⬆️  PedidoDAO.__init__()")
        self.__database = database_dependency  

    def create(self, objPedido: Pedido) -> int:
        SQL = "INSERT INTO pedido (nomePedido) VALUES (%s);"
        params = (objPedido.nomePedido,)

        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL, params)
                conn.commit()
                insert_id = cursor.lastrowid
        if not insert_id:
            raise Exception("Falha ao inserir pedido")
        print("✅ PedidoDAO.create()")
        return insert_id

    def delete(self, pedido: Pedido) -> bool:
        SQL = "DELETE FROM pedido WHERE idPedido = %s;"
        params = (pedido.idPedido,)

        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL, params)
                conn.commit()
                affected = cursor.rowcount
        print("✅ PedidoDAO.delete()")
        return affected > 0

    def update(self, objPedido: Pedido) -> bool:
        SQL = "UPDATE pedido SET nomePedido = %s WHERE idPedido = %s;"
        params = (objPedido.nomePedido, objPedido.idPedido)

        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL, params)
                conn.commit()
                affected = cursor.rowcount

        print("✅ PedidoDAO.update()")
        return affected > 0

    def findAll(self) -> list[dict]:
        SQL = "SELECT * FROM pedido;"

        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL)
                resultados = cursor.fetchall()

        print(f"✅ PedidoDAO.findAll() -> {len(resultados)} registros encontrados")
        return resultados

    def findById(self, idPedido: int) -> dict | None:
        resultados = self.findByField("idPedido", idPedido)
        print("✅ PedidoDAO.findById()")
        return resultados[0] if resultados else None

    def findByField(self, field: str, value) -> list[dict]:
        allowed_fields = ["idPedido", "nomePedido"]
        if field not in allowed_fields:
            raise ValueError(f"Campo inválido para busca: {field}")

        SQL = f"SELECT * FROM pedido WHERE {field} = %s;"
        params = (value,)

        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL, params)
                resultados = cursor.fetchall()

        print("✅ PedidoDAO.findByField()")
        return resultados
